/**
 * Created by Jibran on 5/15/19.
 */
public class FileException extends RuntimeException {
    public FileException() {
        super("The max number of files has been found!");
    }
}
