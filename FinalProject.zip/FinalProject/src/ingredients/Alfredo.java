package ingredients;
import mainClasses.Money;

/**
 * Created by Jibran on 6/12/19.
 */
public class Alfredo extends Base { // subclass of Base, same constructor as Base
    public Alfredo(String desc, Money m, int cal) {
        super(desc, m, cal);
    }
}
