package ingredients;
import mainClasses.Money;

/**
 * Created by Jibran on 6/13/19.
 */
public class Mozzarella extends Cheese {
    public Mozzarella(String desc, Money m, int cal) {
        super(desc, m, cal);
    }
}
