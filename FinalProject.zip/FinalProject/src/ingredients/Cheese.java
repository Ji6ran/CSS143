package ingredients;

import mainClasses.Money;

public class Cheese extends Ingredient { // subclass of Ingredient, same constructor.

	public Cheese(String desc, Money m, int cal) {
		super(desc, m, cal);
	}

}
