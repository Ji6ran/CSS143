package ingredients;
import mainClasses.Money;

/**
 * Created by Jibran on 6/12/19.
 */
public class Marinara extends Base { // subclass of Base with same constructor
    public Marinara(String desc, Money m, int cal) {
        super(desc, m, cal);
    }
}
