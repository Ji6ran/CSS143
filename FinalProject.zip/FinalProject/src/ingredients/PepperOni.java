package ingredients;
import mainClasses.Money;

/**
 * Created by Jibran on 6/12/19.
 */
public class PepperOni extends Meat { // subclass of Meat, same constructor as super class
    public PepperOni(String desc, Money m, int cal) {
        super(desc, m, cal);
    }
}
